﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

      
        private void button1_Click_1(object sender, EventArgs e)
        {
            //Type Selection Fn1353

          if (radioButton2.Checked == true)
            {
                if (radioButton5.Checked == true)
                {
                    ListViewItem item = new ListViewItem("Calligrapgic Design");
                    item.SubItems.Add("1");
                    item.SubItems.Add("10");
                    listView1.Items.Add(item);
              
                }
                else if (radioButton6.Checked == true)
                {
                    ListViewItem item = new ListViewItem("Calligrapgic Design");
                    item.SubItems.Add("1");
                    item.SubItems.Add("10");
                    listView1.Items.Add(item);
             
                }
                else if (radioButton7.Checked == true)
                {
                    ListViewItem item = new ListViewItem("Calligrapgic Design");
                    item.SubItems.Add("1");
                    item.SubItems.Add("10");
                    listView1.Items.Add(item);
                
                }
            }

            else if (radioButton3.Checked == true)
            {
                if (radioButton5.Checked == true)
                {
                    ListViewItem item = new ListViewItem("Digital Print");
                    item.SubItems.Add("1");
                    item.SubItems.Add("20");
                    listView1.Items.Add(item);
              
                }
                else if (radioButton6.Checked == true)
                {
                    ListViewItem item = new ListViewItem("Digital Print");
                    item.SubItems.Add("1");
                    item.SubItems.Add("20");
                    listView1.Items.Add(item);
              
                }
                else if (radioButton7.Checked == true)
                {
                    ListViewItem item = new ListViewItem("Digital Print");
                    item.SubItems.Add("1");
                    item.SubItems.Add("20");
                    listView1.Items.Add(item);
            
                }
            }

            else if (radioButton4.Checked == true)
            {
                if (radioButton5.Checked == true)
                {
                    ListViewItem item = new ListViewItem("Embroided Print");
                    item.SubItems.Add("1");
                    item.SubItems.Add("30");
                    listView1.Items.Add(item);
            
                }
                else if (radioButton6.Checked == true)
                {
                    ListViewItem item = new ListViewItem("Embroided Print");
                    item.SubItems.Add("1");
                    item.SubItems.Add("30");
                    listView1.Items.Add(item);
               
                }
                else if (radioButton7.Checked == true)
                {
                    ListViewItem item = new ListViewItem("Embroided Print");
                    item.SubItems.Add("1");
                    item.SubItems.Add("30");
                    listView1.Items.Add(item);
              
                }
            }


            //color Selection

            if (checkBox1.Checked == true)
            {
                ListViewItem item = new ListViewItem("  Color: White");
                item.SubItems.Add("");
                item.SubItems.Add("7");
                listView1.Items.Add(item);

            }
            
            if (checkBox2.Checked == true)
            {
                ListViewItem item = new ListViewItem("  Color: Sky Blue");
                item.SubItems.Add("");
                item.SubItems.Add("7");
                listView1.Items.Add(item);
          
            }

            if (checkBox3.Checked == true)
            {
                ListViewItem item = new ListViewItem("  Color: Mergenda");
                item.SubItems.Add("");
                item.SubItems.Add("7");
                listView1.Items.Add(item);
         
            }

            if (checkBox4.Checked == true)
            {
                ListViewItem item = new ListViewItem("  Color: Baby Pink");
                item.SubItems.Add("");
                item.SubItems.Add("7");
                listView1.Items.Add(item);
             
            }

            if (checkBox5.Checked == true)
            {
                ListViewItem item = new ListViewItem("  Color: Yellow");
                item.SubItems.Add("");
                item.SubItems.Add("7");
                listView1.Items.Add(item);
            
            }

            if (checkBox6.Checked == true)
            {
                ListViewItem item = new ListViewItem("  Color: Light Green");
                item.SubItems.Add("");
                item.SubItems.Add("7");
                listView1.Items.Add(item);
          
            }

            if (checkBox7.Checked == true)
            {
                ListViewItem item = new ListViewItem("  Color: See Green");
                item.SubItems.Add("");
                item.SubItems.Add("7");
                listView1.Items.Add(item);
            
            }

            if (checkBox8.Checked == true)
            {
                ListViewItem item = new ListViewItem("  Color: Black");
                item.SubItems.Add("");
                item.SubItems.Add("7");
                listView1.Items.Add(item);
       
            }

            if (checkBox9.Checked == true)
            {
                ListViewItem item = new ListViewItem("  Color: Navy Blue");
                item.SubItems.Add("");
                item.SubItems.Add("7");
                listView1.Items.Add(item);
            
            }

            if (checkBox10.Checked == true)
            {
                ListViewItem item = new ListViewItem("  Color: Purple");
                item.SubItems.Add("");
                item.SubItems.Add("7");
                listView1.Items.Add(item);
        
            }

            if (checkBox11.Checked == true)
            {
                ListViewItem item = new ListViewItem("  Color: Red");
                item.SubItems.Add("");
                item.SubItems.Add("7");
                listView1.Items.Add(item);
              
            }

            if (checkBox12.Checked == true)
            {
                ListViewItem item = new ListViewItem("  Color: Orange");
                item.SubItems.Add("");
                item.SubItems.Add("7");
                listView1.Items.Add(item);
       
            }


            if (checkBox13.Checked == true)
            {
                ListViewItem item = new ListViewItem("  Color: Dark Green");
                item.SubItems.Add("");
                item.SubItems.Add("7");
                listView1.Items.Add(item);
           
            }

            if (checkBox14.Checked == true)
            {
                ListViewItem item = new ListViewItem("  Color: Grey");
                item.SubItems.Add("");
                item.SubItems.Add("7");
                listView1.Items.Add(item);
        
            }
              
            double total = 0;
            double hst = 0;
            double totaldue = 0;

            foreach (ListViewItem item in listView1.Items)
            {
                total += Convert.ToDouble(item.SubItems[2].Text);
            }

           
            totaldue =  total;

            string hstDisplay = hst.ToString("c2");
            string totalDisplay = totaldue.ToString("c2");
            string amount = total.ToString("c2");
            
           
            textBox10.Text = totalDisplay;

            tabControl1.SelectTab("tabPage2");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab("tabPage1");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab("tabPage3");
            textBox19.Text = textBox10.Text;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
            radioButton5.Checked = true;
           
            textBox10.Enabled = false;
            textBox19.Enabled = false;
            textBox21.Enabled = false;
            
            comboBox2.Items.Add("Cash");
            comboBox2.Items.Add("Credit Card");
           

            button8.Enabled = false;

        }

      
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char q = e.KeyChar;
            if (!Char.IsDigit(q) && q != 8)
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char q = e.KeyChar;
            if (!Char.IsDigit(q) && q != 8)
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            char q = e.KeyChar;
            if (!Char.IsDigit(q) && q != 8)
            {
                e.Handled = true;
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            char q = e.KeyChar;
            if (!Char.IsDigit(q) && q != 8)
            {
                e.Handled = true;
            }
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            char q = e.KeyChar;
            if (!Char.IsDigit(q) && q != 8)
            {
                e.Handled = true;
            }
        }

        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            char q = e.KeyChar;
            if (!Char.IsDigit(q) && q != 8)
            {
                e.Handled = true;
            }
        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            char q = e.KeyChar;
            if (!Char.IsDigit(q) && q != 8)
            {
                e.Handled = true;
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
           
            textBox10.Text = "";

        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox20_KeyPress(object sender, KeyPressEventArgs e)
        {
            char q = e.KeyChar;
            if (!Char.IsDigit(q) && q != 8 && q != 46)
            {
                e.Handled = true;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab("tabPage2");
        }

        private void button7_Click(object sender, EventArgs e)
        {


            if (textBox11.Text == "" || textBox12.Text == "" || textBox13.Text == "" || textBox20.Text == "" || comboBox2.Text == "")
            {
                MessageBox.Show("Please fill in required fields");
            }
    
            else
            {
                string money = textBox19.Text;
                char[] dollars = { '$' };
                string paymoney = money.TrimStart(dollars);
                double paymentDue = Convert.ToDouble(paymoney);
                double amountPaid = Convert.ToDouble(textBox20.Text);
                double change = 0;
                change = amountPaid - paymentDue;
                textBox21.Text = change.ToString("c2");

                if (change < 0)
                {
                    MessageBox.Show("Please pay your balance");

                }

                else
                {
                    button8.Enabled = true;
                }
                  

            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
           DialogResult dialog = MessageBox.Show("Thanks for ordering. Your ordered items will be ready and delivered in 30 minutes. Do you want to order some more?", "Exit", MessageBoxButtons.YesNo);

           if (dialog == DialogResult.Yes)
           {

               //Clearing all data
               checkBox1.Checked = false;
               checkBox2.Checked = false;
               checkBox3.Checked = false;
               checkBox4.Checked = false;
               checkBox5.Checked = false;
               checkBox6.Checked = false;
               checkBox7.Checked = false;
               checkBox8.Checked = false;
               checkBox9.Checked = false;
               checkBox10.Checked = false;
               checkBox11.Checked = false;
               checkBox12.Checked = false;
               checkBox13.Checked = false;
               checkBox14.Checked = false;
              

             
               listView1.Items.Clear();
              
               textBox10.Text = "";

               textBox11.Text = "";
               textBox12.Text = "";
               textBox13.Text = "";
               textBox14.Text = "";
              
               textBox16.Text = "";
             
               textBox18.Text = "";
               textBox19.Text = "";
               textBox20.Text = "";
               textBox21.Text = "";
              
               comboBox2.Text = "";

               tabControl1.SelectTab("tabPage1");
           }

           else if(dialog == DialogResult.No)
           {
               this.Close();
           }
        
        
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.Text == "Cash")
            {
                textBox18.Enabled = false;
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox19_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
} 
//cpfn
